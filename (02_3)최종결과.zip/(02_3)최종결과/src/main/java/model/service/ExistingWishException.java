package model.service;

public class ExistingWishException extends Exception {
	private static final long serialVersionUID = 1L;

	public ExistingWishException() {
		super();
	}

	public ExistingWishException(String arg0) {
		super(arg0);
	}
}
